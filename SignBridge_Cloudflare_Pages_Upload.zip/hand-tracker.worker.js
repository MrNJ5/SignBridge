import { FilesetResolver, HandLandmarker } from 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14';

let landmarker = null;
let activeDelegate = 'CPU';

async function init() {
  const wasmRoot = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm';
  const modelAssetPath = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
  const vision = await FilesetResolver.forVisionTasks(wasmRoot);
  const common = {
    runningMode: 'VIDEO',
    numHands: 2,
    minHandDetectionConfidence: 0.5,
    minHandPresenceConfidence: 0.5,
    minTrackingConfidence: 0.45
  };
  try {
    landmarker = await HandLandmarker.createFromOptions(vision, {
      ...common,
      baseOptions: { modelAssetPath, delegate: 'GPU' }
    });
    activeDelegate = 'GPU';
  } catch (gpuError) {
    console.warn('Worker GPU delegate unavailable; falling back to CPU.', gpuError);
    landmarker = await HandLandmarker.createFromOptions(vision, {
      ...common,
      baseOptions: { modelAssetPath }
    });
    activeDelegate = 'CPU';
  }
  self.postMessage({ type: 'READY', delegate: activeDelegate });
}

self.onmessage = async (event) => {
  const data = event.data || {};
  if (data.type === 'INIT') {
    try {
      await init();
    } catch (error) {
      self.postMessage({ type: 'INIT_ERROR', error: error?.message || String(error) });
    }
    return;
  }
  if (data.type !== 'FRAME') return;
  const bitmap = data.bitmap;
  if (!bitmap) return;
  try {
    if (!landmarker) throw new Error('Hand model is not initialized');
    const started = performance.now();
    const result = landmarker.detectForVideo(bitmap, data.timestampMs);
    const inferenceMs = performance.now() - started;
    const landmarks = (result.landmarks || []).map(hand => hand.map(p => ({ x: p.x, y: p.y, z: p.z })));
    const handedness = (result.handedness || []).map(categories => categories.map(c => ({ categoryName: c.categoryName, displayName: c.displayName, score: c.score })));
    self.postMessage({ type: 'RESULT', landmarks, handedness, timestampMs: data.timestampMs, inferenceMs, sessionId: data.sessionId });
  } catch (error) {
    self.postMessage({ type: 'FRAME_ERROR', error: error?.message || String(error), sessionId: data.sessionId });
  } finally {
    bitmap.close();
  }
};
