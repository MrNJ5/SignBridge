/*
  Supabase public browser configuration. The anon key is designed to be public.
  Database and Storage access must be protected by the supplied RLS policies.
  NEVER place a Supabase service_role key in this file.
*/
window.SIGNBRIDGE_SUPABASE_CONFIG = {
  url: "YOUR_SUPABASE_PROJECT_URL",
  anonKey: "YOUR_SUPABASE_ANON_KEY"
};
